package com.tujuhsembilan.xmartjava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XmartJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmartJavaApplication.class, args);
	}

}
