package com.tujuhsembilan.xmartjava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmartJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
